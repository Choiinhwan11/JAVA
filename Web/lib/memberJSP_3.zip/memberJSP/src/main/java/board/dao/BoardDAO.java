package board.dao;

public class BoardDAO {

}
